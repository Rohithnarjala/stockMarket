package com.cognizant.stockMarketCharting.fileuploadservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
